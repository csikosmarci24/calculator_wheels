import sys
from PyQt5.QtWidgets import QDialog, QApplication

from szamologep import ui_calculator

"""""
Számológép példa megvalósítása Pythonban
PyQt és PyUIC segítségével
A calculator.ui fájl Qt Designerben szerkeszthető, ha változik, az alábbi parancsot kell kiadni Pycharm terminalban:

pyuic5 calculator.ui --output ui_calculator.py

Ez a ui_calculator.py fájlba generálja a felület megjelenését, ezt tudjuk használni a továbbiakban
"""""


class Calculator(QDialog, ui_calculator.Ui_Dialog):
    # konstruktor: QDialog az egész felület alapja, ezért itt ezt is létre kell hozni
    def __init__(self):
        QDialog.__init__(self)
        # setupUI: a generált fájl egyik metódusa, itt jönnek létre az objektumok
        self.setupUi(self)

        # eseménykezelés beállítása: adott gomb megnyomásakor függvény végrehajtása
        self.addButton.clicked.connect(self.add)
        self.subtractButton.clicked.connect(self.subtract)
        self.multiplyButton.clicked.connect(self.multiply)
        self.divideButton.clicked.connect(self.divide)

    # függvények: bonyolultabb backend esetén ezek törzsét érdemes külön fájlba kiszervezni
    # felületet közvetlenül befolyásoló részek itt vannak
    def add(self):
        # stringek float-tá alakítása, az eredmény végéről a 0-k levágása, majd visszaalakítás stringgé
        self.resultField.setText(str('{0:g}'.format(float(self.opField1.text()) + float(self.opField2.text()))))

    def subtract(self):
        self.resultField.setText(str('{0:g}'.format(float(self.opField1.text()) - float(self.opField2.text()))))

    def multiply(self):
        self.resultField.setText(str('{0:g}'.format(float(self.opField1.text()) * float(self.opField2.text()))))

    def divide(self):
        if float(self.opField2.text()) != 0:
            self.resultField.setText(str('{0:g}'.format(float(self.opField1.text()) / float(self.opField2.text()))))
        else:
            print("0-val nem osztunk!")


def run():
    app = QApplication(sys.argv)
    dialog = Calculator()
    dialog.show()
    app.exec_()
