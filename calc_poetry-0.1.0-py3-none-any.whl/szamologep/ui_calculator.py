# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'calculator.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(640, 480)
        self.addButton = QtWidgets.QPushButton(Dialog)
        self.addButton.setGeometry(QtCore.QRect(75, 189, 40, 40))
        self.addButton.setObjectName("addButton")
        self.subtractButton = QtWidgets.QPushButton(Dialog)
        self.subtractButton.setGeometry(QtCore.QRect(243, 189, 40, 40))
        self.subtractButton.setObjectName("subtractButton")
        self.multiplyButton = QtWidgets.QPushButton(Dialog)
        self.multiplyButton.setGeometry(QtCore.QRect(385, 189, 40, 40))
        self.multiplyButton.setObjectName("multiplyButton")
        self.divideButton = QtWidgets.QPushButton(Dialog)
        self.divideButton.setGeometry(QtCore.QRect(531, 189, 40, 40))
        self.divideButton.setObjectName("divideButton")
        self.opField1 = QtWidgets.QLineEdit(Dialog)
        self.opField1.setGeometry(QtCore.QRect(75, 77, 200, 40))
        self.opField1.setObjectName("opField1")
        self.opField2 = QtWidgets.QLineEdit(Dialog)
        self.opField2.setGeometry(QtCore.QRect(385, 77, 200, 40))
        self.opField2.setObjectName("opField2")
        self.resultField = QtWidgets.QLineEdit(Dialog)
        self.resultField.setGeometry(QtCore.QRect(220, 367, 200, 40))
        self.resultField.setObjectName("resultField")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Calculator"))
        self.addButton.setText(_translate("Dialog", "+"))
        self.subtractButton.setText(_translate("Dialog", "-"))
        self.multiplyButton.setText(_translate("Dialog", "*"))
        self.divideButton.setText(_translate("Dialog", "/"))
        self.opField1.setPlaceholderText(_translate("Dialog", "1. operandus"))
        self.opField2.setPlaceholderText(_translate("Dialog", "2. operandus"))
